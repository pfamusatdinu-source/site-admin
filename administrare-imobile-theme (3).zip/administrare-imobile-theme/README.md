# Administrare Imobile MDM - Tema WordPress

Temă WordPress profesională pentru PFA Mușat Dinu Mihai - Administrare Imobile

## Instalare

### Metoda 1: Upload prin WordPress Admin
1. Comprimați întregul folder `administrare-imobile-theme` într-un fișier .zip
2. Mergeți în WordPress Admin → Appearance → Themes → Add New
3. Click pe "Upload Theme"
4. Selectați fișierul .zip și click "Install Now"
5. Activați tema după instalare

### Metoda 2: Upload prin FTP
1. Conectați-vă la serverul dumneavoastră prin FTP
2. Navigați la `/wp-content/themes/`
3. Încărcați folderul `administrare-imobile-theme` în directorul themes
4. Mergeți în WordPress Admin → Appearance → Themes
5. Activați tema "Administrare Imobile MDM"

## Configurare

### 1. Setați Pagina Principală
- Mergeți la Settings → Reading
- Selectați "A static page" pentru "Your homepage displays"
- Creați o pagină nouă și setați-o ca homepage

### 2. Configurați Meniul
- Mergeți la Appearance → Menus
- Creați un meniu nou numit "Primary Menu"
- Adăugați link-uri custom cu următoarele URLs:
  - Acasă: #home
  - Servicii: #services
  - Despre: #about
  - Contact: #contact
- Asignați meniul la locația "Primary Menu"

### 3. Configurați Formularul de Contact
Formularul de contact este integrat și trimite email-uri la: pfamusatdinu@gmail.com

Pentru a schimba adresa de email:
- Editați fișierul `functions.php`
- Căutați linia: `$to = 'pfamusatdinu@gmail.com';`
- Înlocuiți cu adresa dorită

### 4. Personalizare Logo (Opțional)
- Mergeți la Appearance → Customize → Site Identity
- Încărcați un logo personalizat dacă doriți

## Structura Fișierelor

```
administrare-imobile-theme/
├── style.css           # Stylesheet principal și informații temă
├── functions.php       # Funcții PHP și configurare temă
├── header.php         # Header template
├── footer.php         # Footer template
├── index.php          # Template principal
├── images/
│   └── hero-background.png  # Imaginea de fundal pentru hero section
├── js/
│   └── scripts.js     # JavaScript personalizat
└── README.md          # Acest fișier
```

## Caracteristici

✅ Design profesional și modern
✅ Responsive (se adaptează pe mobile, tablet, desktop)
✅ Animații smooth și efecțe vizuale
✅ Formular de contact funcțional
✅ Secțiuni: Hero, Servicii, Despre, Contact
✅ Optimizat pentru performanță
✅ SEO friendly
✅ Imagini de fundal personalizate

## Personalizare

### Modificarea Culorilor
Editați variabilele CSS din `style.css` (liniile 12-19):
```css
:root {
    --primary: #1a3a52;    /* Culoare principală */
    --secondary: #d4af37;   /* Culoare secundară (auriu) */
    --accent: #8b7355;      /* Culoare accent */
    --light: #f5f3ef;       /* Fundal deschis */
}
```

### Modificarea Conținutului
Editați fișierul `index.php` pentru a modifica:
- Textul din secțiunile Hero, Servicii, Despre, Contact
- Statisticile din secțiunea Despre
- Informațiile de contact

### Schimbarea Imaginii de Fundal
Înlocuiți fișierul `images/hero-background.png` cu imaginea dorită (păstrați același nume).

## Support

Pentru probleme tehnice sau întrebări despre temă, contactați dezvoltatorul.

## Date Contact (Afișate pe Site)

📞 Telefon: +40 722 453 974
✉️ Email: pfamusatdinu@gmail.com
📍 Adresă: București, România

## Versiune

**Versiune:** 1.0
**Data:** Ianuarie 2026
**Compatibilitate:** WordPress 5.0+
**Licență:** GPL v2 or later

---

© 2026 PFA Mușat Dinu Mihai - Administrare Imobile
