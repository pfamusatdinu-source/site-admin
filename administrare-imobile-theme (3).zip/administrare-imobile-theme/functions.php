<?php
/**
 * Administrare Imobile MDM Theme Functions
 */

// Theme Setup
function administrare_imobile_setup() {
    // Add theme support
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo');
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption'));
    
    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'administrare-imobile'),
    ));
}
add_action('after_setup_theme', 'administrare_imobile_setup');

// Enqueue styles and scripts
function administrare_imobile_scripts() {
    // Google Fonts
    wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@300;400;600;700&family=Montserrat:wght@300;400;500;600&display=swap', array(), null);
    
    // Theme stylesheet
    wp_enqueue_style('administrare-imobile-style', get_stylesheet_uri(), array(), '1.0');
    
    // Theme scripts
    wp_enqueue_script('administrare-imobile-scripts', get_template_directory_uri() . '/js/scripts.js', array(), '1.0', true);
}
add_action('wp_enqueue_scripts', 'administrare_imobile_scripts');

// Register widget areas
function administrare_imobile_widgets_init() {
    register_sidebar(array(
        'name'          => __('Footer Widget Area', 'administrare-imobile'),
        'id'            => 'footer-widget-area',
        'description'   => __('Appears in the footer section of the site.', 'administrare-imobile'),
        'before_widget' => '<div class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
}
add_action('widgets_init', 'administrare_imobile_widgets_init');

// Custom Contact Form Handler
function handle_contact_form() {
    if (isset($_POST['contact_form_submit']) && isset($_POST['contact_form_nonce'])) {
        // Verify nonce for security
        if (!wp_verify_nonce($_POST['contact_form_nonce'], 'contact_form_action')) {
            wp_redirect(add_query_arg('contact', 'error', home_url('/#contact')));
            exit;
        }
        
        // Sanitize input
        $name = sanitize_text_field($_POST['name']);
        $email = sanitize_email($_POST['email']);
        $phone = sanitize_text_field($_POST['phone']);
        $message = sanitize_textarea_field($_POST['message']);
        
        // Validate email
        if (!is_email($email)) {
            wp_redirect(add_query_arg('contact', 'invalid_email', home_url('/#contact')));
            exit;
        }
        
        // Email settings
        $to = 'pfamusatdinu@gmail.com';
        $subject = 'Mesaj nou de pe site - ' . $name;
        
        // HTML email body
        $body = '<html><body>';
        $body .= '<h2>Mesaj nou de pe site</h2>';
        $body .= '<p><strong>Nume:</strong> ' . esc_html($name) . '</p>';
        $body .= '<p><strong>Email:</strong> ' . esc_html($email) . '</p>';
        $body .= '<p><strong>Telefon:</strong> ' . esc_html($phone) . '</p>';
        $body .= '<p><strong>Mesaj:</strong></p>';
        $body .= '<p>' . nl2br(esc_html($message)) . '</p>';
        $body .= '<hr>';
        $body .= '<p><small>Trimis de pe ' . get_bloginfo('name') . ' la ' . date('d.m.Y H:i') . '</small></p>';
        $body .= '</body></html>';
        
        // Headers
        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . get_bloginfo('name') . ' <noreply@' . $_SERVER['HTTP_HOST'] . '>',
            'Reply-To: ' . $email
        );
        
        // Send email
        $sent = wp_mail($to, $subject, $body, $headers);
        
        // Log for debugging (optional - remove in production)
        if (!$sent) {
            error_log('Contact form email failed to send to: ' . $to);
        }
        
        if ($sent) {
            wp_redirect(add_query_arg('contact', 'success', home_url('/#contact')));
            exit;
        } else {
            wp_redirect(add_query_arg('contact', 'error', home_url('/#contact')));
            exit;
        }
    }
}
add_action('template_redirect', 'handle_contact_form');

// Enable HTML emails
add_filter('wp_mail_content_type', function() {
    return 'text/html';
});

// Customize excerpt length
function administrare_imobile_excerpt_length($length) {
    return 30;
}
add_filter('excerpt_length', 'administrare_imobile_excerpt_length');

// Remove default WordPress styles that might interfere
function administrare_imobile_dequeue_styles() {
    wp_dequeue_style('wp-block-library');
    wp_dequeue_style('wp-block-library-theme');
}
add_action('wp_enqueue_scripts', 'administrare_imobile_dequeue_styles', 100);
