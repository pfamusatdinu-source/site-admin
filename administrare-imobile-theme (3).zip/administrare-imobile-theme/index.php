<?php get_header(); ?>

<section id="home" class="hero">
    <div class="container">
        <div class="hero-content">
            <h1>
                <strong>PFA Mușat Dinu Mihai</strong>
                Administrare Imobile Profesională
            </h1>
            <div class="decorative-line"></div>
            <p>Gestionăm proprietățile dumneavoastră cu profesionalism, dedicare și transparență. Soluții complete pentru administrarea eficientă a imobilelor rezidențiale și comerciale.</p>
            <a href="#contact" class="cta-button">Solicită o Consultație</a>
        </div>
    </div>
</section>

<section id="services" class="services">
    <div class="container">
        <div class="section-title scroll-reveal">
            <h2>Serviciile Noastre</h2>
            <p>Oferim o gamă completă de servicii pentru administrarea profesională a proprietăților</p>
        </div>
        <div class="services-grid">
            <div class="service-card scroll-reveal">
                <div class="service-icon">🏢</div>
                <h3>Administrare Condominii</h3>
                <p>Gestionare completă a asociațiilor de proprietari, organizare ședințe, întocmire procese-verbale și rapoarte financiare periodice.</p>
            </div>
            <div class="service-card scroll-reveal">
                <div class="service-icon">📋</div>
                <h3>Contabilitate & Financiar</h3>
                <p>Întocmire bugete, colectare contribuții, gestionare fonduri și raportare financiară transparentă către proprietari.</p>
            </div>
            <div class="service-card scroll-reveal">
                <div class="service-icon">🔧</div>
                <h3>Întreținere & Reparații</h3>
                <p>Coordonare lucrări de întreținere, identificare furnizori verificați, supervizare executare și control calitate.</p>
            </div>
            <div class="service-card scroll-reveal">
                <div class="service-icon">📄</div>
                <h3>Consultanță Juridică</h3>
                <p>Asistență în aspecte legale, contracte cu furnizori, respectarea normelor în vigoare și reprezentare în fața autorităților.</p>
            </div>
            <div class="service-card scroll-reveal">
                <div class="service-icon">💼</div>
                <h3>Gestionare Utilități</h3>
                <p>Administrare contracte utilități, verificare facturi, repartizare cheltuieli și optimizare costuri.</p>
            </div>
            <div class="service-card scroll-reveal">
                <div class="service-icon">📊</div>
                <h3>Raportare Transparentă</h3>
                <p>Rapoarte lunare detaliate, platformă online pentru accesul proprietarilor și transparență totală în administrare.</p>
            </div>
        </div>
    </div>
</section>

<section id="about" class="about">
    <div class="container">
        <div class="about-content">
            <div class="about-text scroll-reveal">
                <h2>Despre Noi</h2>
                <div class="decorative-line"></div>
                <p><strong>PFA Mușat Dinu Mihai</strong> oferă servicii profesionale de administrare imobile, axate pe transparență, eficiență și satisfacția clienților.</p>
                <p>Cu o experiență solidă în domeniu, asigurăm gestionarea optimă a proprietăților dumneavoastră, de la aspecte administrative și financiare până la întreținere și relația cu furnizorii.</p>
                <p>Misiunea noastră este să oferim proprietarilor liniște deplină, știind că investițiile lor sunt în mâini de încredere și sunt administrate cu profesionalism maxim.</p>
            </div>
            <div class="stats scroll-reveal">
                <div class="stat-item">
                    <span class="stat-number">100%</span>
                    <span class="stat-label">Transparență</span>
                </div>
                <div class="stat-item">
                    <span class="stat-number">24/7</span>
                    <span class="stat-label">Disponibilitate</span>
                </div>
                <div class="stat-item">
                    <span class="stat-number">10+</span>
                    <span class="stat-label">Ani Experiență</span>
                </div>
                <div class="stat-item">
                    <span class="stat-number">50+</span>
                    <span class="stat-label">Clienți Mulțumiți</span>
                </div>
            </div>
        </div>
    </div>
</section>

<section id="contact" class="contact">
    <div class="container">
        <div class="contact-grid">
            <div class="scroll-reveal">
                <h2>Contactați-ne</h2>
                <div class="decorative-line"></div>
                <p style="margin-bottom: 2rem; opacity: 0.9;">Suntem aici pentru a vă ajuta cu orice întrebări sau necesități legate de administrarea proprietății dumneavoastră.</p>
                <div class="contact-info">
                    <div class="contact-item">
                        <div class="contact-item-icon">📞</div>
                        <div class="contact-item-content">
                            <h4>Telefon</h4>
                            <p><a href="tel:+40722453974">+40 722 453 974</a></p>
                        </div>
                    </div>
                    <div class="contact-item">
                        <div class="contact-item-icon">✉️</div>
                        <div class="contact-item-content">
                            <h4>Email</h4>
                            <p><a href="mailto:pfamusatdinu@gmail.com">pfamusatdinu@gmail.com</a></p>
                        </div>
                    </div>
                    <div class="contact-item">
                        <div class="contact-item-icon">📍</div>
                        <div class="contact-item-content">
                            <h4>Adresă</h4>
                            <p>București, România</p>
                        </div>
                    </div>
                    <div class="contact-item">
                        <div class="contact-item-icon">🕒</div>
                        <div class="contact-item-content">
                            <h4>Program</h4>
                            <p>Luni - Vineri: 09:00 - 18:00<br>Sâmbătă: 10:00 - 14:00</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="scroll-reveal">
                <form method="post" action="<?php echo esc_url(home_url('/')); ?>">
                    <?php wp_nonce_field('contact_form_action', 'contact_form_nonce'); ?>
                    <div class="form-group">
                        <label for="name">Nume Complet</label>
                        <input type="text" id="name" name="name" placeholder="Introduceți numele dumneavoastră" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" placeholder="exemplu@email.ro" required>
                    </div>
                    <div class="form-group">
                        <label for="phone">Telefon</label>
                        <input type="tel" id="phone" name="phone" placeholder="+40 xxx xxx xxx">
                    </div>
                    <div class="form-group">
                        <label for="message">Mesaj</label>
                        <textarea id="message" name="message" placeholder="Descrieți necesitățile dumneavoastră..." required></textarea>
                    </div>
                    <input type="submit" name="contact_form_submit" value="Trimite Mesaj">
                </form>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>
