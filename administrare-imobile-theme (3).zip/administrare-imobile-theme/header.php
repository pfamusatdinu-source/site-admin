<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<nav>
    <div class="container">
        <a href="<?php echo esc_url(home_url('/')); ?>" class="logo">
            MDM
            <span>Administrare Imobile</span>
        </a>
        <?php
        wp_nav_menu(array(
            'theme_location' => 'primary',
            'container'      => false,
            'menu_class'     => '',
            'fallback_cb'    => 'administrare_imobile_default_menu',
        ));
        ?>
    </div>
</nav>

<?php
// Default menu if no menu is set
function administrare_imobile_default_menu() {
    echo '<ul>';
    echo '<li><a href="#home">Acasă</a></li>';
    echo '<li><a href="#services">Servicii</a></li>';
    echo '<li><a href="#about">Despre</a></li>';
    echo '<li><a href="#contact">Contact</a></li>';
    echo '</ul>';
}
?>
