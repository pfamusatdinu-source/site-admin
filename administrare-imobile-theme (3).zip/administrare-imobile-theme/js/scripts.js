// Theme JavaScript file
// This file is enqueued in functions.php

// Additional custom scripts can be added here if needed
console.log('Administrare Imobile Theme loaded successfully');
