<footer>
    <div class="container">
        <p>&copy; <?php echo date('Y'); ?> PFA Mușat Dinu Mihai - Administrare Imobile. Toate drepturile rezervate.</p>
    </div>
</footer>

<script>
// Smooth scrolling
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Scroll reveal animation
const revealElements = document.querySelectorAll('.scroll-reveal');

const revealOnScroll = () => {
    const windowHeight = window.innerHeight;
    revealElements.forEach(element => {
        const elementTop = element.getBoundingClientRect().top;
        const revealPoint = 100;
        
        if (elementTop < windowHeight - revealPoint) {
            element.classList.add('active');
        }
    });
};

window.addEventListener('scroll', revealOnScroll);
revealOnScroll(); // Initial check

// Add stagger delay to service cards
document.querySelectorAll('.service-card').forEach((card, index) => {
    card.style.animationDelay = `${index * 0.1}s`;
});

// Form submission notification
<?php if (isset($_GET['contact'])): ?>
    <?php if ($_GET['contact'] == 'success'): ?>
        alert('✅ Mulțumim pentru mesaj! Vă vom contacta în curând.');
        window.location.hash = 'contact';
    <?php elseif ($_GET['contact'] == 'error'): ?>
        alert('❌ A apărut o eroare la trimiterea mesajului. Vă rugăm să ne contactați direct la telefon sau email.');
        window.location.hash = 'contact';
    <?php elseif ($_GET['contact'] == 'invalid_email'): ?>
        alert('⚠️ Adresa de email introdusă nu este validă. Vă rugăm să verificați și să încercați din nou.');
        window.location.hash = 'contact';
    <?php endif; ?>
<?php endif; ?>
</script>

<?php wp_footer(); ?>
</body>
</html>
